<?php
$this->load->helper('functions_helper');
?>
<html>
	<head>
		<title>پرنت بل</title>
		<style type="text/css">
			.border-right{
				border-right: 1px black solid;
			}
			.twenty{
				width: 25%;
			}
			.rx{
				width: 100%;
			    vertical-align: top;
			    padding-left: 20px;
			    padding-top: 20px;
			}
			table{
				width: 100%;
			}
		</style>
		<script> window.onload= function (e) { window.print();} </script>
	</head>
	<body>
			<table>
				<tr><br><br>
					<td colspan="2" style="text-align: center;">
					<h2>وزارت صحت عامه</h2>
					<h3>لابراتوار دندانسازی برادران شیرزاد</h3>
					</td>
				</tr>
			</table>
			<table style="border:1px black solid; direction: rtl;">
				<tr>
					<td>
						تاریخ &nbsp;&nbsp; :
						<?php echo $result['day'];?>-<?php echo $result['month'];?>-<?php echo $result['dob'];?>
					</td>
					<td></td>
					<td>
						شماره مسلسل: <?php echo $result['hmis_no']; ?>
					</td>
				</tr>
			</table>
			<table style="border:1px black solid; direction: rtl;">
				<tr >
					<td class="border-right twenty">
						نام داکتر: <?php echo $result['patient_name']; ?>
					</td>
					<td class="border-right twenty">
						نام پدر: <?php echo $result['guardian_name']; ?>
					</td>
					<td class="twenty">
						آدرس: <?php echo $result['address']; ?>
					</td>
					<td class="twenty">
						شماره تلفن: <?php echo $result['mobileno']; ?>
					</td>
				</tr>
			</table>
			
			<table  style="border:1px black solid; direction: rtl;">
					  
						<?php 
						if(isset($lab_lab))
						{
					     	foreach($lab_lab as $std)
							{
							?>   
							<tr>
								<td>
								<?php echo $std['test_name'];?>
								</td> 
								<td>
								 <?php echo $std['duplicate']; ?> &nbsp; ساخت
								</td>
								<td>
								 <?php echo $std['fees']; $sum += $std['fees']; ?> افغانی
								</td>
								<td>
								 <?php echo $std['day']; ?>-<?php echo $std['month']; ?>-<?php echo $std['year']; ?>
								</td>
							</tr>
							<?php 
							}

				    	}  ?>
				<?php 
						if(isset($opd_details))
						{
					     	foreach($opd_details as $std)
							{
							?>  
							<tr>
								<td>
								 رسید به    &nbsp; <?php echo $std['name'];?>&nbsp; <?php echo $std['surname'];?>
								</td>
								<td>
								  
								</td>
								
								<td>
								 <?php echo $std['amount']; $paid += $std['amount']; ?>  افغانی
								</td>
								<td>
								 <?php echo $std['bp']; ?>-<?php echo $std['symptoms']; ?>-<?php echo $std['casualty']; ?>
								</td>
							</tr>
							<?php 
							}
							
				    	}  ?>
				<tr >
					<td style="padding-left:15px;"><strong>مجموع  بدهکاری</strong></td>
					<td></td>
					<td><b><?php echo $sum;?> افغانی</b></td>
				</tr>

				<tr >
					<td style="padding-left:15px;"><strong>مجموع رسید ها</strong></td>
					<td></td>
					<td><b><?php echo $paid;?> افغانی</b></td>
				</tr>
				<tr >
					<td style="padding-left:15px;"><strong>مجموع باقیات</strong></td>
					<td></td>
					<td><b><?php echo $sum-$paid;?> افغانی</></td>
				</tr>

				<tr >
					<td style="padding-left:15px;">توضیحات اضافی: ____________________________<br><br></td>
					<td> </td>
				</tr>
				

			</table>

			<?php
				echo '<br>'."Signature";
			?>
			<?php
				
				echo '<br>'."Signature";
			?>
		</body>

</html>